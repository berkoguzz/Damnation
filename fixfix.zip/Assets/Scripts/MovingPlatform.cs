using UnityEngine;

// Script'in ad�n� MovingPlatform2D yapabilirsin
public class MovingPlatform : MonoBehaviour
{
    // 1. Gidece�i noktalar� Unity edit�r�nden atamak i�in
    public Transform waypoint_A;
    public Transform waypoint_B;

    // 2. Platformun h�z�
    public float speed = 3.0f;

    // 3. Platformun o an gitmekte oldu�u hedef
    private Transform currentTarget;

    void Start()
    {
        // Oyuna ba�larken ilk hedef B noktas� olsun
        currentTarget = waypoint_B;
    }

    void Update()
    {
        // Platformu mevcut hedefe do�ru hareket ettir
        // Vector3.MoveTowards 2D pozisyonlar i�in de sorunsuz �al���r (z eksenini 0 kabul eder)
        transform.position = Vector3.MoveTowards(transform.position, currentTarget.position, speed * Time.deltaTime);

        // Platform hedefe �ok yakla�t�ysa (veya ula�t�ysa)
        if (Vector3.Distance(transform.position, currentTarget.position) < 0.1f)
        {
            // Hedefi de�i�tir
            if (currentTarget == waypoint_B)
            {
                currentTarget = waypoint_A;
            }
            else
            {
                currentTarget = waypoint_B;
            }
        }
    }

    // OYUNCUNUN PLATFORM �LE HAREKET ETMES� ���N (2D)

    // Platforma bir nesne temas etti�inde (2D)
    private void OnCollisionEnter2D(Collision2D collision)
    {
        // Platforma temas eden nesnenin etiketi "Player" ise
        if (collision.gameObject.CompareTag("Player"))
        {
            // Oyuncuyu platformun �ocu�u (child) yap.
            // B�ylece platform hareket edince oyuncu da onunla hareket eder.
            collision.transform.SetParent(this.transform);
        }
    }

    // Oyuncu platformdan ayr�ld���nda (2D)
    private void OnCollisionExit2D(Collision2D collision)
    {
        // Oyuncu platformdan ayr�ld���nda
        if (collision.gameObject.CompareTag("Player"))
        {
            // Oyuncunun "child" ili�kisini bitir (parent'�n� null yap).
            collision.transform.SetParent(null);
        }
    }
}