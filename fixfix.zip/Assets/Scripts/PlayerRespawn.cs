using UnityEngine;

public class PlayerRespawn : MonoBehaviour
{
    private Vector3 startPosition;   // Sabit doğma yeri
    private Rigidbody2D rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        startPosition = transform.position; // Oyunun başındaki pozisyonu kaydet
    }

    public void Respawn()
    {
        if (rb != null)
            rb.linearVelocity = Vector2.zero;

        transform.position = startPosition;
    }
}
